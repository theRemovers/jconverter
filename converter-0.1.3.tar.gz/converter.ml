(*
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
#  USA.
*)

open Images
open OImages
open Info

type output = Rgb16 | Cry16

let output_format = ref Rgb16

let clut_mode = ref false

let ascii_output = ref true

let target_dir = ref "./"

let overwrite = ref false

let opt_clut = ref false

let bpp_clut = ref 8

let mode15bit = ref false

let rgb24mode = ref false

let gray = ref false

let glass = ref false

let keep_positive = ref true
let keep_negative = ref true

let rgb24_of_rgb24 c = 
  let v1 = ((c.r land 0xff) lsl 8) lor (c.g land 0xff)
  and v2 = c.b land 0xff in
    (v1,v2)

let rgb16_of_rgb24 c = 
  let r = (c.r lsr 3) land 0x1f
  and g = (c.g lsr 2) land 0x3f
  and b = (c.b lsr 3) land 0x1f
  in
    (r lsl 11) lor (b lsl 6) lor g

let pi = 4. *. atan(1.)

let rad_of_deg x = (x *. 2. *. pi) /. 360.

let cosd x = cos (rad_of_deg (float_of_int x))
let sind x = sin (rad_of_deg (float_of_int x))
let tand x = tan (rad_of_deg (float_of_int x))

let round x = int_of_float (x +. 0.5) 

let check_pos_neg x =
  if !keep_positive && !keep_negative then x
  else
    if !keep_positive then max x 0
    else if !keep_negative then min x 0
    else 0

let cry16_of_rgb24 c =
  let sat4 n = min (max n 0) 15 in
    if c.r = 0 && c.g = 0 && c.b = 0 then 0 
    else
      let y = max (max c.r c.g) c.b in
      let f x = if y = 0 then 0. else (float_of_int (x * 255)) /. (float_of_int y) in
      let r_d,g_d,b_d = (f c.r),(f c.g),(f c.b) in
      let x = (cosd 30) *. r_d -. (cosd 30) *. b_d 
      and w = -. (sind 30) *. r_d +. g_d -. (sind 30) *. b_d 
    in
      let x',y' =
	if (w >= x *. (tand (-30))) && (w <= x *. (tand 30)) then 
	  (x /. (34. *. (cosd 30))),(w /. 17.)
	else 
	  (x /. (34. *. (cosd 30))),(w /. 34.)
      in
      let c = x' +. 7.5 and r = y' +. 7.5 in
      let (c,r,y) = (sat4 (round c)),(sat4 (round r)),y in
      let c = c land 0xf 
      and r = r land 0xf
      in 
	if !gray then 
	  if !glass then (check_pos_neg (y - 0x80)) land 0xff
	  else y
	else if !glass then 
	  (((check_pos_neg (c - 8)) land 0xf) lsl 12) lor (((check_pos_neg (r - 8)) land 0xf) lsl 8) lor ((check_pos_neg (y - 0x80)) land 0xff)
	else (c lsl 12) lor (r lsl 8) lor y 

let rgb15_of_rgb16 n = n land 0xfffe

let cry15_of_cry16 n = n lor 0x1

let rgb15_of_rgb24 c = rgb15_of_rgb16 (rgb16_of_rgb24 c)

let cry15_of_rgb24 c = cry15_of_cry16 (cry16_of_rgb24 c)

let string_of_char c = String.make 1 c 

let hexstring_of_int ?(dollar = true) nb n =
  let s = ref "" and n = ref n in
    for i = 0 to nb-1 do
      let d = !n land 0xf in
	n := !n lsr 4;
	if (0 <= d) && (d <= 9) then s := (string_of_char (Char.chr (d+(Char.code '0'))))^(!s)
	else s := (string_of_char (Char.chr (d-10+(Char.code 'A'))))^(!s)
    done;
    (if dollar then "$" else "")^(!s)

let cry_attribute () =
  if !gray then 
    if !glass then " (gray & glass)"
    else " (gray)"
  else
    if !glass then " (glass)"
    else ""

let description_of_format () = 
  if !rgb24mode then
    "RGB 24 bits"
  else
    if !clut_mode then
      "Pixel map ("^(string_of_int !bpp_clut)^" bits per pixel)"
    else
      match !output_format with
	| Rgb16 -> "Jaguar RGB "^(if !mode15bit then "15" else "16")
	| Cry16 -> "Jaguar CRY "^(if !mode15bit then "15" else "16")^(cry_attribute())

let load_image src =
  prerr_string "Loading file ";prerr_string src;prerr_newline();
  let img = OImages.load src [] in
    img

let name_label basename =
  if !clut_mode then basename^"_map"
  else basename^"_gfx"

let name_dst basename =
  if !ascii_output then basename^".s" 
  else 
    if !rgb24mode then basename^".rgb24"
    else
      if !clut_mode then basename^".map"
      else
	match !output_format with
	  | Rgb16 -> basename^".rgb"
	  | Cry16 -> basename^".cry"

let name_label_clut basename = basename^"_pal"

let name_clut basename =
  if !ascii_output then
    match !output_format with
      | Rgb16 -> basename^"_rgb_pal.s"
      | Cry16 -> basename^"_cry_pal.s"
  else
    match !output_format with
      | Rgb16 -> basename^"_rgb.pal"
      | Cry16 -> basename^"_cry.pal"

let adjust_width w =
  let w' = 
    if !rgb24mode then
      (((w*4)+7)/8)*2
    else
      if !clut_mode then 
	let q1 = w/(8 / !bpp_clut) in
	let q1 = 
	  if w mod (8 / !bpp_clut) = 0 then q1
	  else q1+1
	in
	let q = q1 / 8 in
	let q = 
	  if q1 mod 8 = 0 then q
	  else q+1
	in
	  q * 8 * (8 / !bpp_clut)
      else  (((w*2)+7)/8)*4 
  in
    if w' <> w then
      begin
	prerr_string "extending width from ";
	prerr_int w;
	prerr_string " to ";
	prerr_int w';
	prerr_newline()
      end;
    w'

let phrase_width w =
  if !rgb24mode then
    (assert (w mod 2 = 0);w/2)
  else
    if !clut_mode then 
      let q1 = w/(8 / !bpp_clut) in
      let q1 = 
	if w mod (8 / !bpp_clut) = 0 then q1
	else q1+1
      in
	(assert(q1 mod 8 = 0);q1/8)
    else (assert(w mod 4 = 0);w/4)

let tool_info () =
  "; Converted with 'Jaguar image converter' (version "^(Compile_info.version)^") by Seb/The Removers\n"

let output_header stream src labelname w h = 
  if !ascii_output then
    begin
      output_string stream (tool_info ());
      output_string stream "\t.phrase\n";
      output_string stream (labelname^":\n");
      output_string stream ("; "^(Filename.basename src)^"\n");
      output_string stream ("; "^(string_of_int w)^" x "^(string_of_int h)^"\n");
      output_string stream ("; "^(description_of_format ())^"\n");
      output_string stream ("; "^(string_of_int (phrase_width w))^" phrases per line\n");
    end

let description_of_pal () =
  match !output_format with
    | Rgb16 -> "CLUT RGB "^(if !mode15bit then "15" else "16")
    | Cry16 -> "CLUT CRY "^(if !mode15bit then "15" else "16")

let output_clut_header stream src labelname nb = 
  if !ascii_output then
    begin
      output_string stream (tool_info ());
      output_string stream "\t.phrase\n";
      output_string stream (labelname^":\n");
      output_string stream ("; "^(Filename.basename src)^"\n");
      output_string stream ("; "^(string_of_int nb)^" colors\n");
      output_string stream ("; "^(description_of_pal ())^"\n")
    end

let safe_open_out s =
  if !overwrite then
    Some(open_out s)
  else
    try
      let stream = open_in s in
	close_in stream;
	None
    with _ -> Some(open_out s)

let counter_by_line = 16

let reset_ascii,finish_ascii,output_ascii_long,output_ascii_word,output_ascii_byte =
  let counter = ref 0 in
  let reset_ascii () = counter := 0
  and finish_ascii stream = 
    if !ascii_output then output_string stream "\n"
  and output_ascii header stream value = 
    if !counter = 0 then output_string stream ("\t"^header^"\t")
    else output_string stream ", ";
    output_string stream value;
    incr counter;
    if !counter >= counter_by_line then
      begin
	output_string stream "\n"; 
	counter := 0
      end
  in
  let output_ascii_long stream (v1,v2) = output_ascii "dc.l" stream ((hexstring_of_int 4 v1)^(hexstring_of_int ~dollar:false 4 v2))
  and output_ascii_word stream v = output_ascii "dc.w" stream (hexstring_of_int 4 v)
  and output_ascii_byte stream v = output_ascii "dc.b" stream (hexstring_of_int 2 v)
  in reset_ascii,finish_ascii,output_ascii_long,output_ascii_word,output_ascii_byte

let write_out dstname f =
  let ostream = try safe_open_out dstname with _ -> None in
    match ostream with
      | None -> prerr_string ("error while creating "^dstname);prerr_newline()
      | Some(stream)  -> 
	  begin
	    reset_ascii ();
	    f stream;
	    finish_ascii stream;
	    close_out stream
	  end

let output_word stream v =
  let h = (v lsr 8) land 0xff
  and l = v land 0xff in
    output_byte stream h;
    output_byte stream l

let output_long stream (v1,v2) = 
  output_word stream v1;
  output_word stream v2

let out_long stream v =
  if !ascii_output then output_ascii_long stream v
  else output_long stream v

let out_word stream v =
  if !ascii_output then
    output_ascii_word stream v
  else
    output_word stream v

let out_byte stream v =
  if !ascii_output then
    output_ascii_byte stream v
  else
    output_byte stream (v land 0xff)

let main () =
  let _ = Arg.parse ["-rgb",(Arg.Unit(fun () -> output_format := Rgb16)),"rgb16 output format";
		     "-cry",(Arg.Unit(fun () -> output_format := Cry16)),"cry16 output format";
		     "--ascii",(Arg.Set(ascii_output)),"source output (same as --assembly)"; 
		     "--assembly",(Arg.Set(ascii_output)),"assembly file"; 
		     "--no-ascii",(Arg.Clear(ascii_output)),"data output (same as --binary)";
		     "--binary",(Arg.Clear(ascii_output)),"binary file";
		     "--target-dir",(Arg.Set_string(target_dir)),"set target directory";
		     "--clut",(Arg.Set(clut_mode)),"clut mode";
		     "--no-clut",(Arg.Clear(clut_mode)),"true color mode";
		     "--opt-clut",(Arg.Set(opt_clut)),"optimise low resolution images";
		     "--no-opt-clut",(Arg.Clear(opt_clut)),"optimise low resolution images";
		     "--15-bits",(Arg.Set(mode15bit)),"15 bits mode";
		     "--16-bits",(Arg.Clear(mode15bit)),"16 bits mode";
		     "--true-color",(Arg.Set(rgb24mode)),"true color mode";
		     "--reduced-color",(Arg.Clear(rgb24mode)),"reduced color mode";
		     "--gray",(Arg.Set(gray)),"gray (CRY intensities)";
		     "--glass",(Arg.Set(glass)),"glass (CRY relative)";
		     "--positive",(Arg.Unit(fun () -> keep_negative := false; keep_positive := true)),"keep positive delta";
		     "--negative",(Arg.Unit(fun () -> keep_negative := true; keep_positive := false)),"keep negative delta";
		     "--both",(Arg.Unit(fun () -> keep_negative := true; keep_positive := true)),"keep both delta types";
		     "--normal",(Arg.Unit(fun () -> gray := false; glass := false)),"normal CRY";
		     "--overwrite",(Arg.Set(overwrite)),"overwrite existing files";
		     "--no-overwrite",(Arg.Clear(overwrite)),"do not overwrite existing files";] 
	    (fun src ->
	       let img = load_image src in
	       let name = Filename.chop_extension src in
	       let basename = Filename.basename name in
	       let labelname = name_label basename in
	       let dst = name_dst basename in
	       let conv = 
		 match !output_format with 
		   | Rgb16 -> 
		       if !mode15bit then rgb15_of_rgb24 
		       else rgb16_of_rgb24
		   | Cry16 -> 
		       if !mode15bit then cry15_of_rgb24 
		       else cry16_of_rgb24
	       in
		 if !rgb24mode then
		   begin
		     let img = rgb24 (
		       match OImages.tag img with
			 | Rgb24(_) -> img
			 | Index8(img) -> img#to_rgb24#coerce
			 | Index16(img) -> img#to_rgb24#coerce
			 | _ -> failwith "not supported")
		     in
		     let w = img#width and h = img#height in
		     let read x y =
		       if x >= w then { r = 0; g = 0; b = 0 }
		       else img#unsafe_get x y 
		     in
		       let w' = adjust_width w in
			 write_out ((!target_dir)^dst) (fun stream ->
							  output_header stream src labelname w' h;
							  for y = 0 to h-1 do
							    for x = 0 to w'-1 do
							      let color = read x y in
							      let res = rgb24_of_rgb24 color in
								out_long stream res
							    done
							  done)
		   end
		 else
		   if !clut_mode then
		     begin
		       let img =
			 match OImages.tag img with
			   | Index8(img) -> img
			   | _ -> failwith "not supported"
		       in
		       let w = img#width and h = img#height in
		       let nb_colors = img#size in
			 bpp_clut := 8;
			 let check_index = 
			   let check_mask mask idx =
			     assert (idx land mask = idx);
			     idx
			   in
			     if !opt_clut then
			       if nb_colors <= 2 then
				 begin
				   bpp_clut := 1;
				   check_mask 0x1
				 end
			       else if nb_colors <= 4 then
				 begin
				   bpp_clut := 2;
				   check_mask 0x3
				 end
			       else if nb_colors <= 16 then
				 begin
				   bpp_clut := 4;
				   check_mask 0xf
				 end
			       else check_mask 0xff
			     else check_mask 0xff
			 in
			 let read x y =
			   if x >= w then 0
			   else img#unsafe_get x y
			 in 
			 let w' = adjust_width w in
			 let paldst = name_clut basename in
			   write_out ((!target_dir)^dst) (fun stream ->
							    output_header stream src labelname w' h;
							    let x = ref 0 and value = ref 0 and i = ref 0 in
							      for y = 0 to h-1 do
								x := 0;
								while !x < w' do
								  i := 0;
								  value := 0;
								  while !i < (8 / !bpp_clut) do
								    let idx = check_index (read !x y) in
								      value := !value lsl (!bpp_clut);
								      value := !value lor idx;
								      incr x;
								      incr i;
								  done;
								  out_byte stream !value;
								done
							      done);
			   write_out ((!target_dir)^paldst) (fun stream ->
							       let clutlabelname = name_label_clut basename in
								 output_clut_header stream src clutlabelname nb_colors;
								 for i = 0 to nb_colors-1 do
								   let color = img#query_color i in
								   let res = conv color in
								     out_word stream res
								 done)
		     end
		   else
		     begin
		       let img = rgb24 (
			 match OImages.tag img with
			   | Rgb24(_) -> img
			   | Index8(img) -> img#to_rgb24#coerce
			   | Index16(img) -> img#to_rgb24#coerce
			   | _ -> failwith "not supported")
		       in
		       let w = img#width and h = img#height in
		       let read x y =
			 if x >= w then { r = 0; g = 0; b = 0 }
			 else img#unsafe_get x y 
		       in
		       let w' = adjust_width w in
			 write_out ((!target_dir)^dst) (fun stream ->
							  output_header stream src labelname w' h;
							  for y = 0 to h-1 do
							    for x = 0 to w'-1 do
							      let color = read x y in
							      let res = conv color in
								out_word stream res
							    done
							  done)
		     end
	    ) 
	    ("Jaguar image converter by Seb/The Removers (version "^(Compile_info.version)^")")
  in ()

let _ = main ()


