(*
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
#  USA.
*)

open Images
open OImages
open Info

type output = Rgb16 | Cry16

let output_format = ref Rgb16

let ascii_output = ref true

let target_dir = ref "./"

let rgb16_of_rgb24 c = 
  let r = (c.r lsr 3) land 0x1f
  and g = (c.g lsr 2) land 0x3f
  and b = (c.b lsr 3) land 0x1f
  in
    (r lsl 11) lor (b lsl 6) lor g

let pi = 4. *. atan(1.)

let rad_of_deg x = (x *. 2. *. pi) /. 360.

let cosd x = cos (rad_of_deg (float_of_int x))
let sind x = sin (rad_of_deg (float_of_int x))
let tand x = tan (rad_of_deg (float_of_int x))

let round x = 
  let n = int_of_float (x +. 0.5) in
    min (max n 0) 15

let cry16_of_rgb24 c =
  if c.r = 0 && c.g = 0 && c.b = 0 then 0 
  else
    let y = max (max c.r c.g) c.b in
    let f x = if y = 0 then 0. else (float_of_int (x * 255)) /. (float_of_int y) in
    let r_d,g_d,b_d = (f c.r),(f c.g),(f c.b) in
    let x = (cosd 30) *. r_d -. (cosd 30) *. b_d 
    and w = -. (sind 30) *. r_d +. g_d -. (sind 30) *. b_d 
    in
    let x',y' =
      if (w >= x *. (tand (-30))) && (w <= x *. (tand 30)) then 
	(x /. (34. *. (cosd 30))),(w /. 17.)
      else 
	(x /. (34. *. (cosd 30))),(w /. 34.)
    in
    let c = x' +. 7.5 and r = y' +. 7.5 in
    let (c,r,y) = (round c),(round r),y in
    let c = c land 0xf 
    and r = r land 0xf
    in (c lsl 12) lor (r lsl 8) lor y 

let string_of_char c = String.make 1 c 

let hexstring_of_int nb n =
  let s = ref "" and n = ref n in
    for i = 0 to nb-1 do
      let d = !n land 0xf in
	n := !n lsr 4;
	if (0 <= d) && (d <= 9) then s := (string_of_char (Char.chr (d+(Char.code '0'))))^(!s)
	else s := (string_of_char (Char.chr (d-10+(Char.code 'A'))))^(!s)
    done;
    "$"^(!s)

let counter_by_line = 16

let description_of_format = function
  | Rgb16 -> "Jaguar RGB 16"
  | Cry16 -> "Jaguar CRY 16"

let main () =
  let _ = Arg.parse ["-rgb",(Arg.Unit(fun () -> output_format := Rgb16)),"rgb16 output format";
		     "-cry",(Arg.Unit(fun () -> output_format := Cry16)),"cry16 output format";
		     "--ascii",(Arg.Set(ascii_output)),"source output"; 
		     "--no-ascii",(Arg.Clear(ascii_output)),"data output";
		     "--target-dir",(Arg.Set_string(target_dir)),"set target directory"] 
	    (fun src ->
	       prerr_string "File ";prerr_string src;prerr_newline();
	       let name = Filename.chop_extension src in
	       let basename = Filename.basename name in
	       let labelname = basename^"_gfx" in
	       let img = OImages.load src [] in
	       let img = rgb24 (
		 match OImages.tag img with
		   | Rgb24(_) -> img
		   | Index8(img) -> img#to_rgb24#coerce
		   | Index16(img) -> img#to_rgb24#coerce
		   | _ -> failwith "not supported")
	       in
	       let w = img#width and h = img#height in
	       let conv = 
		 match !output_format with 
		   | Rgb16 -> rgb16_of_rgb24
		   | Cry16 -> cry16_of_rgb24
	       in
	       let dst = if !ascii_output then basename^".s" else 
		 match !output_format with
		   | Rgb16 -> basename^".rgb"
		   | Cry16 -> basename^".cry"
	       in
	       let read x y =
		 if x >= w then { r = 0; g = 0; b = 0 }
		 else img#unsafe_get x y 
	       in
	       let w' = (((w*2)+7)/8)*4 in
		 if w' <> w then
		   begin
		     prerr_string "extending width from ";
		     prerr_int w;
		     prerr_string " to ";
		     prerr_int w';
		     prerr_newline()
		   end;
		 let stream = open_out ((!target_dir)^dst) in
		 if !ascii_output then
		   begin
		     output_string stream "; Converted with 'Jaguar image converter' by Seb/The Removers\n";
		     output_string stream "\t.phrase\n";
		     output_string stream (labelname^":\n");
		     output_string stream ("; "^(Filename.basename src)^"\n");
		     output_string stream ("; "^(string_of_int w')^" x "^(string_of_int h)^"\n");
		     output_string stream ("; "^(description_of_format !output_format)^"\n");
		     output_string stream ("; "^(string_of_int (w'*2/8))^" phrases per line\n");
		       
		   end;
		 let counter = ref 0 in
		   for y = 0 to h-1 do
		     for x = 0 to w'-1 do
		       let color = read x y in
			   let res = conv color in
			     if !ascii_output then
			       begin
				 if !counter = 0 then output_string stream "\tdc.w\t";
				 output_string stream (hexstring_of_int 4 res);
				 incr counter;
				 if !counter < counter_by_line then output_string stream ", "
				 else (output_string stream "\n"; counter := 0)
			       end
			     else
			       begin
				 let c1 = ((res lsr 8) land 0xff)
				 and c2 = (res land 0xff) in
				   output_byte stream c1;
				   output_byte stream c2
			       end
		     done
		   done;
		   close_out stream
	    ) "Jaguar image converter by Seb/The Removers"
  in ()

let _ = main ()

